﻿#include "dllmain.h"
#include <Libraries.h>
#include "CustomMap/Hooks/HookManager.h"
#include <cassert>

#include <winrt/Windows.UI.Notifications.h>
#include <winrt/Windows.Foundation.h>
#include <winrt/Windows.Data.Xml.Dom.h>
#include <winrt/Windows.UI.ViewManagement.h>
#include <winrt/Windows.ApplicationModel.Core.h>
#include <winrt/Windows.UI.Core.h>

using namespace winrt;
using namespace Windows::Data::Xml::Dom;
using namespace Windows::UI::Notifications;

DWORD WINAPI init(LPVOID lpParam) {
    MH_Initialize();
    HookManager::initHooks();
    return 1;
}
static bool initialized = false;

BOOL APIENTRY DllMain( HMODULE hModule,
                       DWORD  ul_reason_for_call,
                       LPVOID lpReserved
                     )
{
    switch (ul_reason_for_call)
    {
    case DLL_PROCESS_ATTACH:
        CreateThread(NULL, NULL, (LPTHREAD_START_ROUTINE)init, hModule, NULL, NULL);
        DisableThreadLibraryCalls(hModule);
        if (!initialized) {
            winrt::init_apartment(winrt::apartment_type::multi_threaded);
            initialized = true;
        }
    case DLL_THREAD_ATTACH:
    case DLL_THREAD_DETACH:
    case DLL_PROCESS_DETACH:
        break;
    }
    return TRUE;
}

data gameData = data();